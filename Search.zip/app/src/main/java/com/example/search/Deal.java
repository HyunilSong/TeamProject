package com.example.search;

public class Deal {
    private String Title;
    private String Writer;

    public Deal() {
    }

    public Deal(String title, String writer) {
        this.Title = Title;
        this.Writer = Writer;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        this.Title = Title;
    }

    public String getWriter() {
        return Writer;
    }

    public void setWriter(String writer) {
        this.Writer = Writer;
    }

}
